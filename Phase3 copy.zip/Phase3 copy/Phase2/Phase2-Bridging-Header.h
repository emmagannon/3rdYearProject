//
//  Phase2-Bridging-Header.h
//  Phase2
//
//  Created by Emma Gannon on 14/03/2016.
//  Copyright © 2016 Emma Gannon. All rights reserved.
//

#ifndef Phase2_Bridging_Header_h
#define Phase2_Bridging_Header_h
#import <sqlite3.h>
#import "FMDatabase.h"
#import "FMDatabase.h"
#import "FMResultSet.h"

#endif /* Phase2_Bridging_Header_h */
