//
//  StudentInfo.swift
//  LetterWritingCheker
//
//  Created by Emma Gannon on 14/03/2016.
//  Copyright © 2016 Emma Gannon. All rights reserved.
//

//import Foundation
import UIKit

class StudentInfo: NSObject
{
    var Name: String = String()
    var RollNo: String = String()
    var marks: String = String()
    
    var smark: String = String()
    var amark: String = String()
    var pmark: String = String()
    var nmark: String = String()
    
    // not currently used
    var date: String = String()
    
}
