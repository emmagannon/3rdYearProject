//
//  ResultViewController.swift
//  PathRecogniser
//
//  Created by Hazel Egan on 17/03/2016.
//  Copyright © 2016 Didier Brun. All rights reserved.
//

import UIKit

class ResultViewController: UIViewController {

    @IBOutlet weak var goAfterS: UIButton!
    @IBOutlet weak var backToS: UIButton!
    @IBOutlet weak var goAfterA: UIButton!
    @IBOutlet weak var backToA: UIButton!
    @IBOutlet weak var goAfterP: UIButton!
    @IBOutlet weak var backToP: UIButton!
    @IBOutlet weak var goAfterN: UIButton!
    @IBOutlet weak var backToN: UIButton!
    @IBOutlet weak var pass: UIImageView!
    @IBOutlet weak var fail: UIImageView!
    var score: Int?
    var letter = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        if(letter == "n"){
            hideP()
            hideA()
            hideS()
            if(score > 3){
                pass.hidden = true
                goAfterN.hidden = true
                goAfterN.enabled = false
            }
            else if (score < 4){
                fail.hidden = true
                backToN.hidden = true
                backToN.enabled = false
            }
        }
        else if(letter == "p"){
            hideN()
            hideA()
            hideS()
            if(score > 3){
                pass.hidden = true
                goAfterP.hidden = true
                goAfterP.enabled = false
            }
            if(score < 4){
                fail.hidden = true
                backToP.hidden = true
                backToP.enabled = false
            }
        }
        else if(letter == "a"){
            hideN()
            hideP()
            hideS()
            if(score > 3){
                pass.hidden = true
                goAfterA.hidden = true
                goAfterA.enabled = false
            }
            else if(score < 4){
                fail.hidden = true
                backToA.hidden = true
                backToA.enabled = false
            }
        }
        else if(letter == "s"){
            hideP()
            hideN()
            hideA()
            if(score > 3){
                pass.hidden = true
                goAfterS.enabled = false
                goAfterS.hidden = true
            }
            else if(score < 4){
                fail.hidden = true
                backToS.hidden = true
                backToS.enabled = false
            }
        }
    }
    
    

    
    func hideN(){
        goAfterN.hidden = true
        goAfterN.enabled = false
        backToN.hidden = true
        backToN.enabled = false
    }
    
    func hideP(){
        backToP.hidden = true
        backToP.enabled = false
        goAfterP.hidden = true
        goAfterP.enabled = false
    }
    
    func hideA(){
        backToA.hidden = true
        backToA.enabled = false
        goAfterA.hidden = true
        goAfterA.enabled = false
    }
    
    func hideS(){
        backToS.hidden = true
        backToS.enabled = false
        goAfterS.hidden = true
        goAfterS.enabled = false
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
